# AUI Button

## @VERSION@

No registries yet.

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1211](https://issues.liferay.com/browse/AUI-1211) Fix Y.Button duplicated icon due labelHTML added by YUI 3.15.0
* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants
* [AUI-1161](https://issues.liferay.com/browse/AUI-1161) Search Button Cancel doesn't stay with input when input is removed from and placed back in DOM
* [AUI-1286](https://issues.liferay.com/browse/AUI-1286) Input with AUI button search cancel immediately loses focus